﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL_FINAL
{
    public class CyberPlanet:Planet
    {
        public const byte Red = 0xa0;
        public const byte Green = 0x79;
        public const byte Blue = 0xad;

        public static bool LevelCompleted = false;

        public static string story = "Welcome to the Cyber Planet!\r\n" 
            + "You have landed on a big city. Full of resources and stores to steal food and money from\r\n" 
            + "Be aware that they have your name on the wanted list. Do not get caught!\r\n"
            + "Are you ready to start stealing?";
        public override byte GetRedColor()
        {
            return Red;
        }

        public override byte GetGreenColor()
        {
            return Green;
        }

        public override byte GetBlueColor()
        {
            return Blue;
        }

        public override void SetLevelCompleted(bool completed)
        {
            LevelCompleted = completed;
        }

        public override bool GetLevelCompleted()
        {
            return LevelCompleted;
        }

        public override string GetStory()
        {
            return story;
        }
    }
}
