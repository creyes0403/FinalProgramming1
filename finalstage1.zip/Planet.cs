﻿using BL_FINAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL_FINAL
{
    //abstract class = blueprint for other classes. In this case it = cannot have just planet objects. Rafael tutoring :)
    public abstract class Planet
    {
        public string Name;

        public abstract byte GetRedColor();
        public abstract byte GetGreenColor();
        public abstract byte GetBlueColor();

        //public bool LevelCompleted = false;

        public abstract void SetLevelCompleted(bool completed);

        public abstract bool GetLevelCompleted();

        public abstract string GetStory();
    }


}
