﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL_FINAL
{
    public class RedPlanet:Planet
    {
        public const byte Red = 0x91;
        public const byte Green = 0x54;
        public const byte Blue = 0x46;

        public static bool LevelCompleted = false;

        public static string story = "Welcome to the Red Planet!\r\n"
            + "You have landed on the hottest planet. Here people do not have many resources.\r\n"
            + "You will need to steal food and money from the market in downtown\r\n"
            + "Are you ready to start stealing?";
        public override byte GetRedColor()
        {
            return Red;
        }

        public override byte GetGreenColor()
        {
            return Green;
        }

        public override byte GetBlueColor()
        {
            return Blue;
        }

        public override void SetLevelCompleted(bool completed)
        {
            LevelCompleted = completed;
        }

        public override bool GetLevelCompleted()
        {
            return LevelCompleted;
        }

        public override string GetStory()
        {
            return story;
        }
    }
}
