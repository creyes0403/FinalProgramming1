﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace BL_FINAL
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    /// Onace again Rafael to the rescue taught me how to do enum and abstracts :)
    public partial class App : Application
    {
        public static RuntimeStatus status = RuntimeStatus.CapturePlayerInfo;
        public static Player player = new Player();
        public static Planet planet;

    }

    public enum RuntimeStatus
    {
        CapturePlayerInfo,
        PrintStory,
        ChoosePlanet,
        RedPlanet1,
        RedPlanet2,
        RedPlanet3,
        RedPlanet4,
        CyberPlanet

    }
}
