﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BL_FINAL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    // We learn how to add sounds Rafael and me together. The audio is based on the classic tada.wav from Windows 3.1
    public partial class MainWindow : Window
    {
        System.Media.SoundPlayer audioPlayer = new System.Media.SoundPlayer("..\\..\\tadasound.wav");

        public MainWindow()
        {
            InitializeComponent();
            CapturePlayerInfo();

            audioPlayer.Play();
        }

        private void YesButton_Click(object sender, RoutedEventArgs e)
        {
            
            switch(App.status)
            {
                case RuntimeStatus.CapturePlayerInfo:
                    if (TextBoxName.Text.Equals(""))
                    {
                        App.player.Name = "Kuma";
                    }
                    else
                    {
                        App.player.Name = TextBoxName.Text;
                    }
                    try 
                    {
                        App.player.Age = Int32.Parse(TextBoxAge.Text);
                    }
                    catch(Exception except)
                    {
                        MessageBox.Show("Excuse me, it has to be a number!");
                        CapturePlayerInfo();
                        return;
                    }
                    //Set variable status to value "PrintStory"
                    App.status = RuntimeStatus.PrintStory;

                    //Print story to the textblock
                    PrintStory();
                    break;

                case RuntimeStatus.PrintStory:
                    ChoosePlanet();
                    break;

                case RuntimeStatus.ChoosePlanet:
                    App.planet = new CyberPlanet();
                    App.status = RuntimeStatus.CyberPlanet;
                    LandOnPlanetCyber();
                    break;

                case RuntimeStatus.RedPlanet1:
                    App.status = RuntimeStatus.RedPlanet2;
                    LandOnPlanetRed();
                    break;

                case RuntimeStatus.RedPlanet2:
                    //player steal from buyer
                    App.status = RuntimeStatus.RedPlanet3;
                    LandOnPlanetRed();
                    break;

                case RuntimeStatus.RedPlanet3:
                    //coffee, bag of apples and mangos, bread and meat
                    App.player.Inventory.Add(new Item("coffee"));
                    App.player.Inventory.Add(new Item("bag of apples"));
                    App.player.Inventory.Add(new Item("mangoes"));
                    App.player.Inventory.Add(new Item("bread"));
                    App.player.Inventory.Add(new Item("meat"));
                    App.status = RuntimeStatus.RedPlanet4;
                    LandOnPlanetRed();
                    break;

                case RuntimeStatus.RedPlanet4:
                    App.status = RuntimeStatus.ChoosePlanet;
                    ChoosePlanet();
                    break;
                    //create new status for after actions. Also add here the items after selecting yes
            }
        }

        private void CapturePlayerInfo()
        {
            DialogStory.Text = "Welcome to the Green Planet!\r\n"
                + "Here, we enjoy the fruits of our mother nature & travel anywhere we like to with the help of the blue flowers that light up in the darkness of the night\r\n"
                + "Please enter your character's data";

            YesButton.Content = "Proceed";

            YesButton.Visibility = Visibility.Visible;
            NoButton.Visibility = Visibility.Hidden;

            TextBoxName.Text = "";
            TextBoxAge.Text = "";
        }

        private void PrintStory()
        {
            YesButton.Content = "Yes";
            NoButton.Content = "No";

            YesButton.Visibility = Visibility.Visible;
            NoButton.Visibility = Visibility.Visible;

            //PlayersName.Text = App.player.Name;
            //PlayersAge.Text = App.player.Age.ToString();

            PlayersName.Visibility = Visibility.Hidden;
            PlayersAge.Visibility = Visibility.Hidden;

            TextBoxName.Visibility = Visibility.Hidden;
            TextBoxAge.Visibility = Visibility.Hidden;

            DialogStory.Text = "Hello "+ App.player.Name+ " You have entered the body of a bandit \r\n" 
                + "He is an Earth Genasi who was abandoned by his mother at three months old and adopted by a gang of bandits the same day. \r\n" 
                + "To survive they taught him how to steal from people that live at the planets he can visit with the help of the blue flowers \r\n" 
                + "Today he is " + App.player.Age.ToString()+ " and he is running low on money and food. It's time to eat a blue flower \r\nAre you ready to go on adventure?";
        }

        private void HaveAGoodDay()
        {
            DialogStory.Text = "Game Over \r\nMaybe in another life you enjoy living. Have a good day!";
            YesButton.Visibility = Visibility.Hidden;
            NoButton.Visibility = Visibility.Hidden;

            PlayersName.Visibility = Visibility.Hidden;
            PlayersAge.Visibility = Visibility.Hidden;

            TextBoxName.Visibility = Visibility.Hidden;
            TextBoxAge.Visibility = Visibility.Hidden;
            
        }
        private void NoButton_Click(object sender, RoutedEventArgs e)
        {
            switch (App.status)
            {
                case RuntimeStatus.PrintStory:  
                    HaveAGoodDay();
                    break;

                case RuntimeStatus.ChoosePlanet:
                    App.planet = new RedPlanet();
                    App.status = RuntimeStatus.RedPlanet1;
                    LandOnPlanetRed();
                    break;

                case RuntimeStatus.RedPlanet1:
                    HaveAGoodDay();
                    break;

                case RuntimeStatus.RedPlanet2:
                    //Steal from seller
                    gameover();
                    break;

                case RuntimeStatus.RedPlanet3:
                    HaveAGoodDay();
                    break;

                case RuntimeStatus.RedPlanet4:
                    HaveAGoodDay();
                    break;
                    //create new status for after actions. Also add here the loser page :) 
            }
        }

        private void ChoosePlanet()
        {
            DialogStory.Text = "Choose your destination";
            YesButton.Content = "Cyber Planet";
            NoButton.Content = "Red Planet";

            App.status = RuntimeStatus.ChoosePlanet;

            //#FF49AB93
            DialogStory.Background = new SolidColorBrush(Color.FromArgb(255, 0x49, 0xAB, 0X93));

            YesButton.Background = new SolidColorBrush(Color.FromArgb(255, CyberPlanet.Red, CyberPlanet.Green, CyberPlanet.Blue));

            NoButton.Background = new SolidColorBrush(Color.FromArgb(255, RedPlanet.Red, RedPlanet.Green, RedPlanet.Blue));

            if(RedPlanet.LevelCompleted)
            {
                NoButton.Visibility = Visibility.Hidden;
            }
            else 
            {
                NoButton.Visibility = Visibility.Visible;
            }

            if(CyberPlanet.LevelCompleted)
            {
                YesButton.Visibility = Visibility.Hidden;
            }
            else
            {
                YesButton.Visibility = Visibility.Visible;
            }
        }

        private void LandOnPlanetRed()
        {
            DialogStory.Background = new SolidColorBrush(Color.FromArgb(255, App.planet.GetRedColor(), App.planet.GetGreenColor(), App.planet.GetBlueColor()));

            YesButton.Background = new SolidColorBrush(Color.FromArgb(255, 0xaa, 0xf9, 0xff));
            
            NoButton.Background = new SolidColorBrush(Color.FromArgb(255, 0xaa, 0xf9, 0xff));

            switch (App.status)
            {
                case RuntimeStatus.RedPlanet1:
                    DialogStory.Text = "Welcome to the Red Planet!\r\n"
                        + "You have landed on the hottest planet. Here people do not have many resources.\r\n"
                        + "You will need to steal food and money from the market in downtown\r\n"
                        + "Are you ready to start stealing?";


                    YesButton.Content = "Yes";
                    NoButton.Content = "No";
                    break;

                case RuntimeStatus.RedPlanet2:
                    DialogStory.Text = "You have entered the downtown market! Now it's time to find a victim\r\n"
                        + "Remember they're used to thieves. Be careful!\r\n" 
                        + "There is a seller who left his backapck unattended and a buyer who has money sticking out of his pocket\r\n"
                        + "Choose who you want to steal from\r\n";

                    YesButton.Content = "Buyer";
                    NoButton.Content = "Seller";
                    break;

                    
                case RuntimeStatus.RedPlanet3:
                    DialogStory.Text = "Target robbed succesfully!\r\n" + "You made $1,200.00."
                        + "There's a stand with different types of food. Would you like to steal the following: coffee, bag of apples and mangos, bread and meat?";
                    YesButton.Content = "Yes";
                    NoButton.Content = "No";
                    break;

                case RuntimeStatus.RedPlanet4:
                    DialogStory.Text = "Target robbed succesfully!\r\n" + "You have stolen the following\r\n" + App.player.displayinventory() ;
                    YesButton.Content = "Continue";
                    NoButton.Content = "Quit";
                    RedPlanet.LevelCompleted = true;
                    break;

            }


        }

        private void LandOnPlanetCyber()
        {
            DialogStory.Background = new SolidColorBrush(Color.FromArgb(255, App.planet.GetRedColor(), App.planet.GetGreenColor(), App.planet.GetBlueColor()));
            DialogStory.Text = "";

            YesButton.Content = "Yes";
            YesButton.Background = new SolidColorBrush(Color.FromArgb(255, 0xaa, 0xf9, 0xff));


            NoButton.Content = "No";
            NoButton.Background = new SolidColorBrush(Color.FromArgb(255, 0xaa, 0xf9, 0xff));
        }

        private void gameover()
        {
            DialogStory.Text = "Game Over \r\nYou got caught! Sucks to be a loser.\r\nHave a good day!";
            YesButton.Visibility = Visibility.Hidden;
            NoButton.Visibility = Visibility.Hidden;

            PlayersName.Visibility = Visibility.Hidden;
            PlayersAge.Visibility = Visibility.Hidden;

            TextBoxName.Visibility = Visibility.Hidden;
            TextBoxAge.Visibility = Visibility.Hidden;
        }
    }
}
