﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Animation;

namespace BL_FINAL
{
    public class People
    {
        public int Age;
        public string Name;

        public List<Item> Inventory = new List<Item>();

       
    }
}
